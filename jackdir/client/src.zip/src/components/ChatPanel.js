// src/components/ChatPanel.js
import React, { useState } from 'react';
import axios from 'axios';

const ChatPanel = ({ selectedPaths }) => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState('gpt-4o');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    // Append the latest user message
    const newMessages = [...messages, { role: 'user', content: input }];
    setMessages(newMessages);
    setInput('');

    try {
      setIsLoading(true);
      const response = await axios.post('http://localhost:6789/api/chat', {
        prompt: input,
        api_key: apiKey,
        model: model,
        selected_paths: selectedPaths,
        include_hidden: true,        // You can adjust this based on your needs
        respect_gitignore: true,     // Likewise, adjust or add additional configuration here
      });

      setMessages([...newMessages, { role: 'assistant', content: response.data.response }]);
    } catch (error) {
      console.error('Chat error:', error);
      setMessages([...newMessages, { role: 'error', content: 'Error communicating with AI' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="uk-padding-small">
      {/* API Key & Model Inputs */}
      <div className="uk-margin">
        <input
          className="uk-input uk-margin-small-bottom"
          type="text"
          value={apiKey}
          onChange={(e) => setApiKey(e.target.value)}
          placeholder="Enter API Key"
        />
        <input
          className="uk-input"
          type="text"
          value={model}
          onChange={(e) => setModel(e.target.value)}
          placeholder="Model (e.g., gpt-4o)"
        />
      </div>

      <div className="uk-height-medium uk-overflow-auto uk-margin-small-bottom">
        {messages.map((msg, i) => (
          <div key={i} className={`uk-margin-small ${msg.role === 'user' ? 'uk-text-right' : ''}`}>
            <div className={`uk-inline uk-width-1-1`}>
              <div className={`uk-card ${msg.role === 'user' ? 'uk-card-primary' : 'uk-card-default'} uk-card-body uk-padding-small`}>
                {msg.content}
              </div>
            </div>
          </div>
        ))}
        {isLoading && <div className="uk-text-center">Thinking...</div>}
      </div>
      
      <form onSubmit={handleSubmit}>
        <div className="uk-inline uk-width-1-1">
          <input
            className="uk-input"
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask something about the code..."
            disabled={isLoading}
          />
          <button 
            className="uk-button uk-button-primary uk-position-right"
            type="submit"
            disabled={isLoading}
          >
            Send
          </button>
        </div>
      </form>
    </div>
  );
};

export default ChatPanel;
